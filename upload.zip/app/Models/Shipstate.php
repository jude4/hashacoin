<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Shipstate extends Model {
    protected $table = "state";
    protected $guarded = [];
}
