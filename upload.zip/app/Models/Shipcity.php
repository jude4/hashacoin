<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Shipcity extends Model {
    protected $table = "cities";
    protected $guarded = [];
}
