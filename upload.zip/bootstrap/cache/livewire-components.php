<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'payment-links' => 'App\\Http\\Livewire\\PaymentLinks',
  'transactions' => 'App\\Http\\Livewire\\Transactions',
);